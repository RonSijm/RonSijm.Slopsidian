export { default } from "mermaid";
