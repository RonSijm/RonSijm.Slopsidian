export const coreVerificationTargets = Object.freeze([
  "file-explorer", "global-search", "switcher", "graph", "backlink", "canvas", "outgoing-link", "tag-pane", "footnotes", "properties",
  "page-preview", "daily-notes", "templates", "note-composer", "command-palette", "slash-command", "editor-status", "bookmarks", "markdown-importer",
  "zk-prefixer", "random-note", "outline", "word-count", "slides", "audio-recorder", "workspaces", "file-recovery",
]);
