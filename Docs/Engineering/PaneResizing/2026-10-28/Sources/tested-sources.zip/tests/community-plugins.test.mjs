import assert from "node:assert/strict";
import { after, before, test } from "node:test";
import { build } from "esbuild";
import { errorLogStub } from "./error-log-stub.mjs";
import { mkdir, mkdtemp, rm } from "node:fs/promises";
import { createRequire } from "node:module";
import { join } from "node:path";
import { root } from "./host.mjs";

let directory, PluginHost, Commands, current;
const errorElement = { textContent: "", append() {} };
before(async () => {
  await mkdir(join(root, ".runtime"), { recursive: true });
  directory = await mkdtemp(join(root, ".runtime", "community-settings-tests-"));
  const output = join(directory, "model.cjs");
  await build({
    stdin: { contents: 'export { PluginHost } from "./client/plugin-host"; export { Commands } from "./client/app"; export { configureBrowserHost } from "./client/contracts";', resolveDir: root, loader: "ts" },
    outfile: output, bundle: true, platform: "node", format: "cjs", external: ["electron"], loader: { ".css": "empty" }, logLevel: "silent", plugins: [errorLogStub],
  });
  const module = createRequire(import.meta.url)(output);
  PluginHost = module.PluginHost;
  Commands = module.Commands;
  module.configureBrowserHost({ request: (...args) => current.request(...args) });
  globalThis.document = { getElementById: () => errorElement, createElement: () => ({ addEventListener() {} }) };
});
after(async () => {
  delete globalThis.document;
  if (directory) { await rm(directory, { recursive: true }); }
});

function manifest(id, changes = {}) {
  return { id, name: id, version: "1.0.0", description: "", isDesktopOnly: false, error: null, ...changes };
}

test("remote community configuration keeps initial loads restricted and persists explicit trust in the transport overlay", async () => {
  const state = fixture(["good"], undefined, "git:remote", true);
  state.app.loadLocalStorage = () => { throw new Error("Remote restricted mode must not use another local-storage preference"); };
  state.app.saveLocalStorage = () => { throw new Error("Remote restricted mode must persist with the transport's local overlay"); };
  await state.host.restoreEnabled();
  assert.equal(state.host.isRestricted, true); assert.deepEqual(state.starts, []);
  await state.host.setRestricted(false);
  assert.equal(state.host.isRestricted, false); assert.equal(state.configuration().restricted, false);
  assert.deepEqual(state.starts, ["good"]); assert.deepEqual(state.configuration().enabled, ["good"]);
  await state.host.setRestricted(true);
  assert.equal(state.configuration().restricted, true); assert.deepEqual(state.stops, ["good"]);
});

test("failed remote restricted-mode persistence rolls back the running state and keeps the enabled IDs", async () => {
  const state = fixture(["good"], undefined, "git:remote", true);
  await state.host.restoreEnabled(); await state.host.setRestricted(false);
  state.conflict = true;
  await assert.rejects(state.host.setRestricted(true), /changed on disk/);
  assert.equal(state.host.isRestricted, false); assert.equal(state.configuration().restricted, false);
  assert.ok(state.host.getPlugin("good")); assert.deepEqual(state.configuration().enabled, ["good"]);
});

test("unrestricted WASM remote defaults start configured plugins without writing preferences and retain a later explicit pause", async () => {
  const state = fixture(["good"], undefined, "git:remote", true, false);
  state.app.loadLocalStorage = () => { throw new Error("The GitHub transport owns restricted mode"); };
  state.app.saveLocalStorage = () => { throw new Error("The GitHub transport owns restricted mode"); };
  await state.host.restoreEnabled();
  assert.equal(state.host.isRestricted, false); assert.deepEqual(state.starts, ["good"]);
  assert.deepEqual(state.calls.map(call => call.method), ["GET"]);
  await state.host.setRestricted(true);
  assert.equal(state.configuration().restricted, true); assert.deepEqual(state.stops, ["good"]);
  state.host.setManifests([manifest("good")]);
  await state.host.restoreEnabled();
  assert.equal(state.host.isRestricted, true); assert.equal(state.host.getPlugin("good"), null);
  assert.deepEqual(state.starts, ["good"], "Restoring an explicit pause must not start the plugin again");
});

test("native command objects expose live hooks and accept void execution callbacks without concealing explicit rejection", async () => {
  const phases = [], app = { changingVault: false, workspace: {}, hotkeyManager: { addDefaultHotkeys() {}, removeDefaultHotkeys() {} } };
  const commands = new Commands(app);
  commands.addCommand({ id: "editor:save-file", name: "Save", checkCallback: checking => { if (checking) { return true; } phases.push("save"); } });
  const command = commands.commands["editor:save-file"], original = command.checkCallback;
  command.checkCallback = checking => { if (checking) { return original(true); } original(false); phases.push("plugin"); };
  await commands.execute("editor:save-file");
  assert.deepEqual(phases, ["save", "plugin"]);
  command.checkCallback = checking => checking;
  await assert.rejects(commands.execute("editor:save-file"), /declined/);
  commands.removeCommand("editor:save-file");
  assert.equal(Object.hasOwn(commands.commands, "editor:save-file"), false);
  assert.deepEqual(commands.listCommands(), []);
});

test("native editor-check commands receive the active owned editor during availability and execution", async () => {
  const calls = [], editor = {}, view = { editor }, app = { changingVault: false, workspace: { activeEditor: null }, hotkeyManager: { addDefaultHotkeys() {}, removeDefaultHotkeys() {} } };
  const commands = new Commands(app);
  commands.addCommand({ id: "lint", name: "Lint", editorCheckCallback: (checking, actualEditor, actualView) => {
    assert.equal(actualEditor, editor);
    assert.equal(actualView, view);
    calls.push(checking);
    if (checking) { return true; }
  } });
  assert.equal(commands.executeCommandById("lint"), false);
  assert.deepEqual(calls, []);
  app.workspace.activeEditor = view;
  await commands.execute("lint");
  assert.deepEqual(calls, [true, false]);
});

function fixture(enabled = [], manifests = [manifest("good"), manifest("other")], version = "original", remote = false, remoteRestricted = true) {
  let configuration = { root: "browser:vault-a", enabled: [...enabled], version, ...(remote ? { restricted: remoteRestricted } : {}) };
  let preference = null;
  const calls = [], starts = [], stops = [];
  const app = {
    changingVault: false, vault: { rootPath: configuration.root },
    settingsTabs: new Map(), commands: { status: () => [] },
    dotNet: { invokeMethodAsync: async () => {} },
    loadLocalStorage: () => preference,
    saveLocalStorage: (_key, value) => { preference = value; },
  };
  const host = new PluginHost(app);
  host.setManifests(manifests);
  const state = {
    app, host, calls, starts, stops, conflict: false, failing: new Set(), startGate: null,
    request: async (path, method = "GET", body) => {
      calls.push({ path, method, body: structuredClone(body) });
      if (path.startsWith("/api/community-plugins?") && method === "GET") {
        return { status: 200, value: structuredClone(configuration) };
      }
      assert.equal(path, "/api/community-plugins");
      assert.equal(method, "PUT");
      assert.equal(body.root, configuration.root);
      if (state.conflict || body.version !== configuration.version) { return { status: 409, error: "Settings changed on disk." }; }
      configuration = { root: body.root, enabled: [...body.enabled], version: "saved-" + calls.length, ...(remote ? { restricted: body.restricted ?? configuration.restricted } : {}) };
      return { status: 200, value: structuredClone(configuration) };
    },
    configuration: () => structuredClone(configuration),
    preference: () => preference,
    setPreference: value => { preference = value; },
  };
  host.enable = async id => {
    starts.push(id);
    if (state.startGate) { await state.startGate; }
    if (state.failing.has(id)) { throw new Error("Expected startup failure"); }
    host.plugins[id] = {};
    host.enabledPlugins.add(id);
  };
  host.disable = async id => {
    stops.push(id);
    delete host.plugins[id];
    host.enabledPlugins.delete(id);
  };
  current = state;
  return state;
}

test("caught unavailable browser modules remain visible without disabling portable fallbacks or leaking into a new vault selection", async () => {
  const state = fixture(), selection = state.host.selectionVersion;
  state.host.plugins.good = {};
  const requirePlugin = name => state.host.require(name, "good", selection);
  assert.throws(() => requirePlugin("http"), /Unsupported module without the desktop Node runtime: http/);
  assert.deepEqual(state.host.unavailableModulesFor("good"), ["http"]);
  assert.match(state.host.errorFor("good"), /Browser limitation: unavailable modules http/);
  assert.ok(state.host.getPlugin("good"), "A caught optional-module probe must not forcibly disable a portable plugin.");
  const modules = state.host.unavailableModulesFor("good");
  modules.length = 0;
  assert.deepEqual(state.host.unavailableModulesFor("good"), ["http"]);
  assert.equal(typeof requirePlugin("timers/promises").setTimeout, "function");
  await state.host.disable("good");
  state.host.setManifests([manifest("good")]);
  assert.deepEqual(state.host.unavailableModulesFor("good"), []);
  assert.equal(state.host.errorFor("good"), null);
  assert.throws(() => requirePlugin("child_process"), /Unsupported module/);
  assert.deepEqual(state.host.unavailableModulesFor("good"), [], "Old module closures must not attach their warnings to another selection.");
});

test("vault enablement restores compatible plugins, retains missing/incompatible/failed IDs and never writes while reading", async t => {
  t.mock.method(console, "error", () => {});
  const enabled = ["good", "desktop", "future", "bad-version", "missing", "broken", "other"];
  const state = fixture(enabled, [
    manifest("good"), manifest("desktop", { isDesktopOnly: true }), manifest("future", { minAppVersion: "99.0.0" }),
    manifest("bad-version", { minAppVersion: "invalid" }), manifest("broken"), manifest("other"),
  ]);
  state.failing.add("broken");
  state.app.changingVault = true;
  await state.host.restoreEnabled();
  assert.deepEqual(Object.keys(state.host.plugins), ["good", "other"]);
  assert.deepEqual([...state.host.configuredPlugins], enabled);
  assert.deepEqual(state.configuration().enabled, enabled);
  assert.deepEqual(state.calls.map(call => call.method), ["GET"]);
  assert.match(state.host.errorFor("desktop"), /Desktop-only/);
  assert.match(state.host.errorFor("future"), /99\.0\.0/);
  assert.match(state.host.errorFor("bad-version"), /Invalid minAppVersion/);
  assert.match(state.host.errorFor("missing"), /not installed/);
  assert.equal(state.host.isRestricted, false);
  assert.equal(state.host.isManaging, false);
});

test("explicit toggles persist canonical enabled IDs and retain configured plugins unavailable in this host", async () => {
  const state = fixture(["desktop"], [manifest("good"), manifest("desktop", { isDesktopOnly: true })]);
  await state.host.restoreEnabled();
  await state.host.enablePluginAndSave("good");
  assert.deepEqual(state.configuration().enabled, ["desktop", "good"]);
  assert.equal(Boolean(state.host.getPlugin("good")), true);
  await state.host.disablePluginAndSave("good");
  assert.deepEqual(state.configuration().enabled, ["desktop"]);
  assert.equal(state.host.getPlugin("good"), null);
  const writes = state.calls.filter(call => call.method === "PUT");
  assert.equal(writes.length, 2);
  assert.equal(writes[0].body.version, "original");
  assert.equal(writes[1].body.version, "saved-3");
});

test("a failed settings save rolls back the running state for both enable and disable", async () => {
  const state = fixture(["good"]);
  await state.host.restoreEnabled();
  state.conflict = true;
  await assert.rejects(state.host.disablePluginAndSave("good"), /changed on disk/);
  assert.equal(Boolean(state.host.getPlugin("good")), true);
  assert.deepEqual(state.configuration().enabled, ["good"]);
  await assert.rejects(state.host.enablePluginAndSave("other"), /changed on disk/);
  assert.equal(state.host.getPlugin("other"), null);
  assert.deepEqual(state.configuration().enabled, ["good"]);
});

test("retrying an already-configured plugin does not rewrite its enabled list", async () => {
  const state = fixture(["good"]);
  await state.host.restoreEnabled();
  await state.host.disable("good");
  await state.host.enablePluginAndSave("good");
  assert.deepEqual(state.calls.map(call => call.method), ["GET", "GET"]);
  assert.deepEqual(state.configuration().enabled, ["good"]);
});

test("restricted mode is separate from the enabled-ID file and its saved preference survives host restoration", async () => {
  const state = fixture(["good"]);
  await state.host.restoreEnabled();
  await state.host.setRestricted(true);
  assert.equal(state.host.isRestricted, true);
  assert.equal(state.preference(), true);
  assert.equal(state.host.getPlugin("good"), null);
  assert.deepEqual(state.configuration().enabled, ["good"]);
  state.host.setManifests([manifest("good")]);
  await state.host.restoreEnabled();
  assert.equal(state.host.getPlugin("good"), null);
  await state.host.setRestricted(false);
  assert.equal(Boolean(state.host.getPlugin("good")), true);
  assert.equal(state.host.isRestricted, false);
  assert.ok(state.calls.every(call => call.method === "GET"));
});

test("new vaults require opt-in without creating an enabled file until an explicit plugin toggle", async () => {
  const state = fixture([], [manifest("good")], null);
  await state.host.restoreEnabled();
  assert.equal(state.host.isRestricted, true);
  await assert.rejects(state.host.enablePluginAndSave("good"), /Turn on community plugins/);
  assert.equal(state.configuration().version, null);
  await state.host.setRestricted(false);
  assert.equal(state.configuration().version, null);
  await state.host.enablePluginAndSave("good");
  assert.deepEqual(state.configuration().enabled, ["good"]);
  assert.equal(state.calls.find(call => call.method === "PUT").body.version, null);
});

test("restricted-mode persistence failures restore previously running plugins without changing enabled IDs", async () => {
  const state = fixture(["good", "other"]);
  await state.host.restoreEnabled();
  state.app.saveLocalStorage = () => { throw new Error("Profile storage unavailable"); };
  await assert.rejects(state.host.setRestricted(true), /Profile storage unavailable/);
  assert.equal(state.host.isRestricted, false);
  assert.deepEqual(Object.keys(state.host.plugins), ["good", "other"]);
  assert.deepEqual(state.configuration().enabled, ["good", "other"]);
});

test("pending plugin management blocks vault replacement and quiescence waits for persistence", async () => {
  const state = fixture([]);
  await state.host.restoreEnabled();
  let release;
  state.startGate = new Promise(resolve => { release = resolve; });
  const enabling = state.host.enablePluginAndSave("good");
  assert.throws(() => state.host.setManifests([]), /Wait for community/);
  let settled = false;
  const idle = state.host.whenIdle().then(() => { settled = true; });
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(settled, false);
  state.app.changingVault = true;
  await assert.rejects(state.host.enablePluginAndSave("other"), /ready vault/);
  release();
  await enabling;
  await idle;
  assert.deepEqual(state.configuration().enabled, ["good"]);
  assert.equal(settled, true);
});

test("invalid enabled-file reads remain visible and never reset or write settings", async () => {
  const state = fixture([]);
  state.request = async () => ({ status: 422, error: "community-plugins.json must contain an array of plugin IDs." });
  await assert.rejects(state.host.restoreEnabled(), /must contain an array/);
  assert.match(state.host.configurationError, /must contain an array/);
  assert.equal(state.host.isRestricted, true);
  assert.deepEqual(state.configuration().enabled, []);
  assert.deepEqual(state.starts, []);
});
