import hashlib
import json
import re
import subprocess
import zipfile
from pathlib import Path


root = Path.cwd().resolve()
evidence = root / r".runtime\evidence"
destination = root / r"Docs\Engineering\Appearance\2026-10-31"
fingerprint = "51c2d8077524b32c7f4bb864a216d3ecc2dd261479a410ef4c8622c4f4e93b6d"
manifest = json.loads(subprocess.check_output([
    "node", "--input-type=module", "-e",
    'import { join } from "node:path"; import { pathToFileURL } from "node:url"; '
    'const { coreVerificationInputs } = await import(pathToFileURL(join(process.cwd(), '
    '"tools", "core-verification-inputs.mjs")).href); '
    'console.log(JSON.stringify(await coreVerificationInputs(process.cwd())));',
], cwd=root, text=True))
assert manifest["sourceFingerprint"] == fingerprint
assert len(manifest["sources"]) == 436
assert not destination.exists(), "Refusing to replace an existing evidence collection."


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def encoded_json(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def repository_path(value):
    path = (root / value.replace("/", "\\")).resolve()
    assert path.is_relative_to(root), value
    return path


entries = {}
reports = []
artifact_bindings = {}
for name in [
    "appearance-smoke", "appearance-web-smoke",
    "editor-chrome-smoke", "editor-chrome-web-smoke",
    "tags-smoke", "tags-web-smoke",
    "properties-smoke", "properties-web-smoke",
]:
    raw = (evidence / (name + ".json")).read_bytes()
    report = json.loads(raw)
    assert report["status"] == "passed", name
    assert report["sourceFingerprint"] == fingerprint, name
    assert report["artifactStability"] == "verified-through-scenario", name
    assert not report.get("browserErrors") and not report.get("exceptions"), name
    audit = report["errorLogAudit"]
    assert audit["status"] == "passed" and not audit["unexpected"], name
    assert audit["includesFinalTeardown"], name
    audit_raw = (evidence / (name + "-errors.jsonl")).read_bytes()
    assert sha256(audit_raw) == audit["sha256"], name
    entries["reports/" + name + ".json"] = raw
    entries["reports/" + name + "-errors.jsonl"] = audit_raw
    record = {
        "path": "reports/" + name + ".json",
        "host": "actual-folder-wasm" if "-web-" in name else "desktop",
        "checks": len(report["checks"]),
        "sha256": sha256(raw),
        "completedAt": report["completedAt"],
        "errorAudit": {
            "path": "reports/" + name + "-errors.jsonl",
            "sha256": sha256(audit_raw),
            "records": audit["records"],
            "expected": audit["expected"],
            "unexpected": 0,
            "includesFinalTeardown": True,
        },
    }
    if "processes" in report:
        record["processSessions"] = len(report["processes"])
        for artifact in report["artifacts"]:
            path = artifact["path"].replace("/", "\\")
            assert path not in artifact_bindings or artifact_bindings[path] == artifact["sha256"], path
            artifact_bindings[path] = artifact["sha256"]
    else:
        for path, digest in report["sha256"].items():
            path = str(Path(r".runtime\web\wwwroot") / path.replace("/", "\\"))
            assert path not in artifact_bindings or artifact_bindings[path] == digest, path
            artifact_bindings[path] = digest
    reports.append(record)

for path, digest in artifact_bindings.items():
    assert sha256(repository_path(path).read_bytes()) == digest, "Artifact changed: " + path

entries["source-manifest.json"] = encoded_json(manifest)
for source in manifest["sources"]:
    raw = repository_path(source["path"]).read_bytes()
    assert sha256(raw.decode("utf-8").replace("\r\n", "\n").encode("utf-8")) == source["sha256"]
    entries["sources/" + source["path"]] = raw
entries["artifact-manifest.json"] = encoded_json([
    {"path": path, "sha256": digest} for path, digest in sorted(artifact_bindings.items())
])

for path in [
    r"src\RonSijm.Slopsidian\bin\Debug\net10.0\RonSijm.Slopsidian.dll",
    r"src\RonSijm.Slopsidian\wwwroot\js\editor-host.js",
    r"src\RonSijm.Slopsidian\wwwroot\js\editor-host.css",
    r"src\RonSijm.Slopsidian\wwwroot\app.css",
    r".runtime\web\wwwroot\index.html",
    r".runtime\web\wwwroot\js\browser-host.js",
    *[path for path in artifact_bindings if path.endswith(".wasm")],
]:
    entries["artifacts/" + path.replace("\\", "/")] = repository_path(path).read_bytes()

logs = [
    "appearance-build.log", "appearance-publish.log", "appearance-web-static.log",
    "appearance-default-tests.log", "appearance-focused-tests.log",
    "appearance-desktop-run.log", "appearance-web-run.log",
    "appearance-renew-editor-chrome-native.log", "appearance-renew-editor-chrome-web.log",
    "appearance-renew-tags-native.log", "appearance-renew-tags-web.log",
    "appearance-renew-properties-native.log", "appearance-renew-properties-web.log",
    "appearance-smoke.log", "editor-chrome-smoke.log", "tags-smoke.log", "properties-smoke.log",
]
for name in logs:
    entries["logs/" + name] = (evidence / name).read_bytes()
for name, count in [("appearance-default-tests.log", 787), ("appearance-focused-tests.log", 100)]:
    text = (evidence / name).read_text(encoding="utf-8")
    for outcome, number in [("pass", count), ("fail", 0), ("skipped", 0)]:
        assert re.search(rf"(?:\u2139|#)\s+{outcome} {number}(?:\r?\n|$)", text), (name, outcome)

captures = [
    "appearance-light-desktop.png", "appearance-light-web.png",
    "appearance-theme-snippets-desktop.png", "appearance-theme-snippets-web.png",
    "appearance-readonly-desktop.png", "appearance-readonly-web.png",
]
for name in captures:
    entries["captures/" + name] = (evidence / name).read_bytes()

failures = [
    ("appearance-native-attempt-1-", "The fixture now checks the actual CodeMirror darkTheme facet and computed colors, not nonexistent cm-light/cm-dark classes."),
    ("appearance-native-attempt-2-", "Authored fixtures use equal-specificity selectors to exercise normal theme/snippet cascade order, without forced overrides."),
    ("appearance-properties-native-attempt-1-", "Final dialog type selection uses actual Tab/Home/arrows on the closed form select, not JavaScript value assignment. The pointer-open native popup timeout is retained."),
    ("appearance-properties-native-attempt-2-", "The isolated unchanged-source pointer-open dropdown sequence also timed out. Final dialog types use actual closed-select keyboard navigation."),
    ("appearance-properties-native-attempt-3-", "Removing per-key Page.bringToFront did not resolve the dropdown timeout; that hypothesis was reverted. Final dialog selection uses actual Tab/Home/arrows; the popup cause is unestablished."),
    ("appearance-properties-web-attempt-1-", "The scenario now waits for an editable, non-busy input: cache readiness can precede a previous inline commit's readonly/row-refresh completion. Draft/conflict assertions remain unchanged."),
    ("appearance-editor-native-attempt-1-", "Native settings opening timed out once. An isolated unchanged-source retry passed, as did the remaining matched scopes; its cause is unestablished and no assertion/application fix is claimed."),
]
retained_failures = []
for prefix, resolution in failures:
    files = sorted(evidence.glob(prefix + "*"))
    assert files, prefix
    raw_report = next(path for path in files if path.name.endswith("-smoke.json"))
    failed = json.loads(raw_report.read_bytes())
    assert failed["status"] == "failed", raw_report.name
    for path in files:
        assert path.is_file()
        entries["failures/" + path.name] = path.read_bytes()
    retained_failures.append({
        "path": "failures/" + raw_report.name,
        "sourceFingerprint": failed.get("sourceFingerprint"),
        "resolution": resolution,
        "status": "unaccepted-diagnostic-attempt",
    })
entries["retention-script.py"] = Path(__file__).read_bytes()
entries["archive-manifest.json"] = encoded_json([
    {"path": name, "bytes": len(data), "sha256": sha256(data)}
    for name, data in sorted(entries.items())
])

destination.mkdir(parents=True)
archive = destination / "runtime-evidence.zip"
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(entries.items()):
        output.writestr(name, data)
with zipfile.ZipFile(archive) as retained:
    assert retained.testzip() is None
    assert set(retained.namelist()) == set(entries)
    for name, data in entries.items():
        assert sha256(retained.read(name)) == sha256(data), name

receipt = {
    "schemaVersion": 1,
    "reviewedAt": "2026-10-31",
    "testedAt": "2026-10-31",
    "scope": "shared-appearance-self-contained-css-and-dependent-runtime-renewal",
    "status": "passed",
    "sourceFingerprint": fingerprint,
    "sourceCount": len(manifest["sources"]),
    "archive": {
        "path": archive.name,
        "bytes": archive.stat().st_size,
        "entries": len(entries),
        "sha256": sha256(archive.read_bytes()),
        "contents": "All fingerprinted sources, key runtime binaries, raw artifact bindings, eight final reports/audits, complete logs, six reviewed captures, retention code and seven unaccepted diagnostic attempts.",
    },
    "reports": reports,
    "regressions": [
        {"scope": "default", "command": "npm test", "passed": 787, "failed": 0, "skipped": 0, "output": "logs/appearance-default-tests.log"},
        {"scope": "Appearance/native/browser/GitHub", "command": "npm run test:appearance", "passed": 100, "failed": 0, "skipped": 0, "output": "logs/appearance-focused-tests.log"},
    ],
    "buildChecks": ["npm run build", "npm run build:web", "npm run verify:web"],
    "environment": {
        "node": subprocess.check_output(["node", "--version"], text=True).strip(),
        "dotnetSdk": subprocess.check_output([str(root / r".runtime\dotnet\dotnet.exe"), "--version"], text=True).strip(),
        "electronPackage": json.loads((root / r"node_modules\electron\package.json").read_bytes())["version"],
        "browserInput": "Actual-folder WASM uses the owned browser and real OS pickers recorded in each report; rendererNodeIntegration is false.",
    },
    "errorAudits": {
        "includesFinalTeardown": True,
        "unexpectedPersistedRecords": 0,
        "uncaughtExceptions": 0,
        "note": "Deliberate CSS/configuration/conflict/stale-owner notifications and browser bootstrap are exactly accounted. Retained native transport/GPU diagnostics are not a clean-console claim.",
    },
    "reviewedCaptures": ["captures/" + name for name in captures],
    "retainedFailures": retained_failures,
    "limits": [
        "Self-contained trusted whole-interface CSS only, not sandboxed themes, full native DOM/CSS equivalence or new third-party theme/plugin-corpus acceptance.",
        "Imports and resource functions (including escaped names) refuse; lexical validation is not complete CSS syntax validation.",
        "One MiB raw UTF-8 per CSS file, four MiB per selected set, 128 configured snippet names, 256 theme folders plus snippet files, literal safe names up to 200 characters.",
        "No theme catalog/install/update, font-file/image resources, complete font/default controls or automatic external appearance watching.",
        "Existing Mermaid jobs, Web Reader frames and native window chrome are not dynamically rethemed by this tranche.",
        "A failed CSS Reload can already adopt new preferences/base mode while retaining previously accepted CSS; inventory failures survive unrelated successful mode/style-disable saves.",
        "Versioned preference writes preserve unknown values/BOM but may reformat JSON; no cross-file/cross-app/crash transaction is established.",
        "Cached GitHub CSS uses verified readonly blobs and local preference overlays, not an offline app shell or eager full-vault indexing.",
        "The fixed 31-module/140-case contract and historical whole-core badges remain unchanged.",
        "Earlier accepted Properties/Outgoing collections are immutable historical epochs; retained failed attempts are not combined into final acceptance.",
        "No commits, pushes or deployment were performed.",
    ],
}
with (destination / "receipt.json").open("xb") as output:
    output.write(encoded_json(receipt))
print(json.dumps({
    "archive": str(archive.relative_to(root)),
    "entries": len(entries),
    "bytes": archive.stat().st_size,
    "sha256": receipt["archive"]["sha256"],
    "sourceFingerprint": fingerprint,
    "reports": len(reports),
}))
