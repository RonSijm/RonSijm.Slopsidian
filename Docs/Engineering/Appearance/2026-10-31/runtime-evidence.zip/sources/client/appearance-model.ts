export const APPEARANCE_CSS_BYTES = 1024 * 1024;
export type AppearanceMode = "obsidian" | "moonstone" | "system";
export interface AppearanceOptions {
  theme: AppearanceMode;
  cssTheme: string;
  enabledCssSnippets: string[];
}
export class AppearanceError extends Error {}

export function appearanceName(value: unknown): string {
  if (typeof value !== "string" || !value.trim() || value.length > 200 || value.startsWith(".") || /[. ]$|[\\/<>:"|?*\x00-\x1f\x7f]/.test(value) || /^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])($|\.)/i.test(value)) {
    throw new AppearanceError("Use a theme or snippet name without hidden, reserved, traversal or invalid path characters.");
  }
  return value;
}

export function appearanceOptions(data: Record<string, unknown>): AppearanceOptions {
  const theme = data.theme === undefined ? "obsidian" : data.theme;
  if (theme !== "obsidian" && theme !== "moonstone" && theme !== "system") { throw new AppearanceError("Choose dark, light or system appearance."); }
  const cssTheme = data.cssTheme === undefined ? "" : data.cssTheme;
  if (typeof cssTheme !== "string") { throw new AppearanceError("The installed theme name must be text."); }
  if (cssTheme !== "") { appearanceName(cssTheme); }
  const snippets = data.enabledCssSnippets === undefined ? [] : data.enabledCssSnippets;
  if (!Array.isArray(snippets) || snippets.length > 128) { throw new AppearanceError("Enabled CSS snippets must be a list of at most 128 names."); }
  return { theme, cssTheme, enabledCssSnippets: [...new Set(snippets.map(appearanceName))] };
}

export function appearanceCssPath(value: unknown): string {
  if (typeof value !== "string") { throw new AppearanceError("An installed theme or snippet CSS path is required."); }
  const theme = /^\.obsidian\/themes\/([^/]+)\/theme\.css$/.exec(value);
  const snippet = /^\.obsidian\/snippets\/([^/]+)\.[cC][sS][sS]$/.exec(value);
  if (!theme && !snippet) { throw new AppearanceError("Only installed theme.css and top-level CSS snippet files can be loaded."); }
  appearanceName((theme ?? snippet)![1]);
  return value;
}

function cssEscape(text: string, index: number, inString = false): { value: string; next: number } {
  if (/[\n\r\f]/.test(text[index + 1] ?? "")) {
    if (!inString) { throw new AppearanceError("CSS identifiers must not contain escaped newlines."); }
    return { value: "", next: index + (text[index + 1] === "\r" && text[index + 2] === "\n" ? 3 : 2) };
  }
  const hexadecimal = /^[0-9a-f]{1,6}/i.exec(text.slice(index + 1, index + 7));
  if (hexadecimal) {
    const code = Number.parseInt(hexadecimal[0], 16);
    let next = index + 1 + hexadecimal[0].length;
    if (/[\t\n\r\f ]/.test(text[next] ?? "")) { next += text[next] === "\r" && text[next + 1] === "\n" ? 2 : 1; }
    return { value: !code || code > 0x10ffff || code >= 0xd800 && code <= 0xdfff ? "\ufffd" : String.fromCodePoint(code), next };
  }
  if (index + 1 >= text.length) { throw new AppearanceError("The CSS ends with an incomplete escape."); }
  return { value: text[index + 1], next: index + 2 };
}

export function validateAppearanceCss(text: string): void {
  if (new TextEncoder().encode(text).length > APPEARANCE_CSS_BYTES) { throw new AppearanceError("Each appearance stylesheet must be at most 1 MiB."); }
  if (text.includes("\0")) { throw new AppearanceError("Appearance CSS must not contain null characters."); }
  const identifier = (character: string): boolean => /[a-z0-9_-]/i.test(character) || character.charCodeAt(0) >= 128;
  for (let index = 0; index < text.length;) {
    if (text.startsWith("/*", index)) {
      const end = text.indexOf("*/", index + 2);
      if (end < 0) { throw new AppearanceError("The CSS contains an unterminated comment."); }
      index = end + 2;
    } else if (text[index] === '"' || text[index] === "'") {
      const quote = text[index++];
      while (index < text.length && text[index] !== quote) {
        if (/[\n\r\f]/.test(text[index])) { throw new AppearanceError("CSS strings must not contain unescaped newlines."); }
        index = text[index] === "\\" ? cssEscape(text, index, true).next : index + 1;
      }
      if (index === text.length) { throw new AppearanceError("The CSS contains an unterminated string."); }
      index++;
    } else if (text[index] === "@" || text[index] === "\\" || identifier(text[index])) {
      const atRule = text[index] === "@";
      if (atRule) { index++; }
      let name = "";
      while (index < text.length && (text[index] === "\\" || identifier(text[index]))) {
        if (text[index] === "\\") { const escaped = cssEscape(text, index); name += escaped.value; index = escaped.next; }
        else { name += text[index++]; }
      }
      const normalized = name.toLowerCase();
      if (atRule && normalized === "import" || !atRule && text[index] === "(" && ["url", "image-set", "-webkit-image-set", "image", "src"].includes(normalized)) {
        throw new AppearanceError("Only self-contained appearance CSS is supported. Imports and URL/image resources are not loaded.");
      }
    } else { index++; }
  }
}
