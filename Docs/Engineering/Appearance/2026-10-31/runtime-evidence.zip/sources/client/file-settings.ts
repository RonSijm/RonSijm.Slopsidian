import type { App } from "./app";
import { attachmentPath, recordingFolder } from "./audio-paths";
import type { VaultConfigurationDocument } from "./contracts";
import { SettingTab, type SettingDefinitionItem } from "./settings";

export function validateFileSetting(key: string, value: unknown): void {
  if (key === "newFileLocation") {
    if (!["root", "current", "folder"].includes(String(value)) || typeof value !== "string") { throw new Error("Choose root, current or folder for new notes."); }
  } else if (key === "newLinkFormat") {
    if (!["shortest", "relative", "absolute"].includes(String(value)) || typeof value !== "string") { throw new Error("Choose shortest, relative or absolute link paths."); }
  } else if (key === "useMarkdownLinks") {
    if (typeof value !== "boolean") { throw new Error("The Markdown link preference must be Boolean."); }
  } else if (key === "newFileFolderPath") {
    if (typeof value !== "string") { throw new Error("The new-note folder must be a vault path."); }
    if (value !== "/") { attachmentPath(value); }
  } else if (key === "attachmentFolderPath") {
    if (typeof value !== "string") { throw new Error("The attachment folder must be a vault path."); }
    recordingFolder(value, "Folder/Note.md");
  } else { throw new Error("This Files and links setting is not supported: " + key); }
}

export class FileSettings extends SettingTab {
  private document: VaultConfigurationDocument | null = null;
  private writes: Promise<void> = Promise.resolve();

  constructor(app: App) {
    super(app);
    this.containerEl.dataset.fileSettings = "";
    app.registerLeaveGuard(() => this.closeSettings());
  }

  async open(container: HTMLElement): Promise<void> {
    await this.closeSettings();
    this.document = await this.app.configuration.read("app");
    container.replaceChildren(this.containerEl);
    await this.showSettings();
  }

  override async setControlValue(key: string, value: unknown): Promise<void> {
    validateFileSetting(key, value);
    const root = this.app.vault.rootPath;
    const save = async (): Promise<void> => {
      const previous = this.document;
      if (!previous || previous.root !== root || root !== this.app.vault.rootPath || this.app.changingVault || !this.containerEl.isConnected) {
        throw new Error("These Files and links settings belong to an inactive vault or page.");
      }
      this.document = await this.app.configuration.write(previous, { ...previous.data, [key]: value });
    };
    const operation = this.writes.then(save, save);
    this.writes = operation;
    await operation;
  }

  override getSettingDefinitions(): SettingDefinitionItem[] {
    const valid = (key: string) => (value: string): string | void => {
      try { validateFileSetting(key, value); } catch (error) { return error instanceof Error ? error.message : String(error); }
    };
    return [
      { type: "group", heading: "New notes", items: [
        { name: "Default location for new notes", desc: "Applies to bare note names in New note, Quick switcher and missing links. Explicit folder paths keep their destination.", control: { type: "dropdown", key: "newFileLocation", options: { root: "Vault root", current: "Same folder as the current note", folder: "Specified folder" } } },
        { name: "New note folder", desc: "An existing vault folder, or / for the root. A missing folder falls back to the vault root.", control: { type: "folder", key: "newFileFolderPath", includeRoot: true, disabled: () => this.app.vault.getConfig("newFileLocation") !== "folder", validate: valid("newFileFolderPath") } },
      ] },
      { type: "group", heading: "Links and attachments", items: [
        { name: "New link format", desc: "Used by shared file-link generation and Note composer. Paths remain destination-safe when names are ambiguous.", control: { type: "dropdown", key: "newLinkFormat", options: { shortest: "Shortest path when possible", relative: "Relative path to file", absolute: "Absolute path in vault" } } },
        { name: "Use Markdown links", desc: "Shared link generation uses [text](path) instead of [[path]]. Existing links are not rewritten.", control: { type: "toggle", key: "useMarkdownLinks" } },
        { name: "Attachment folder", desc: "Use / for the root, ./ for the note's folder, ./Attachments for a note-relative subfolder, or a vault folder path. Applies to Attach files and Audio recorder.", control: { type: "text", key: "attachmentFolderPath", validate: valid("attachmentFolderPath") } },
      ] },
      { name: "Reload Files and links settings", desc: "Discard this page's old version and read external app.json changes. Existing note bytes are not changed.", action: async () => {
        await Promise.allSettled([this.writes]);
        this.document = await this.app.configuration.read("app");
        this.update();
      } },
    ];
  }
}
