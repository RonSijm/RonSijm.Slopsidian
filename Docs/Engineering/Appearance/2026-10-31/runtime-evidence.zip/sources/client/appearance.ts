import type { App } from "./app";
import { HostError, requestJson, type AppearanceStylesheet, type VaultConfigurationDocument } from "./contracts";
import { reportError } from "./dom";
import { SettingTab, type SettingDefinitionItem } from "./settings";
import { MarkdownView } from "./workspace";
import { APPEARANCE_CSS_BYTES, AppearanceError, appearanceCssPath, appearanceName, appearanceOptions, validateAppearanceCss, type AppearanceMode, type AppearanceOptions } from "./appearance-model";

interface AppearanceAsset { name: string; path: string }
export function isAppearanceFailure(error: unknown): boolean {
  return error instanceof AppearanceError || error instanceof HostError && [400, 403, 404, 409, 413, 415, 422].includes(error.status);
}

export class Appearance extends SettingTab {
  private document: VaultConfigurationDocument | null = null;
  private assets: { themes: AppearanceAsset[]; snippets: AppearanceAsset[] } = { themes: [], snippets: [] };
  private styles: HTMLStyleElement[] = [];
  private writes: Promise<void> = Promise.resolve();
  private assetEpoch = 0;
  private pageEpoch = 0;
  private mode: AppearanceMode = "obsidian";
  private failure = "";
  private inventoryFailure = "";
  private readonly system = window.matchMedia("(prefers-color-scheme: dark)");

  constructor(app: App) {
    super(app);
    this.containerEl.dataset.appearanceSettings = "";
    this.system.addEventListener("change", () => { if (this.mode === "system") { this.applyMode(); } });
    app.registerLeaveGuard(() => this.closeSettings());
  }

  clear(): void {
    this.assetEpoch++;
    this.document = null;
    this.assets = { themes: [], snippets: [] };
    this.styles.forEach(style => style.remove());
    this.styles = [];
    this.mode = "obsidian";
    this.failure = "";
    this.inventoryFailure = "";
    this.applyMode();
  }

  async restore(): Promise<void> {
    const root = this.app.vault.rootPath, epoch = this.assetEpoch;
    const configuration = await this.app.configuration.read("appearance");
    this.assertOwner(root, epoch);
    this.document = configuration;
    const options = appearanceOptions(this.document.data);
    this.mode = options.theme;
    this.applyMode();
    if (options.cssTheme || options.enabledCssSnippets.length) {
      await this.readInventory(root, epoch);
    }
    const prepared = await this.prepareStyles(options, root, epoch);
    this.assertOwner(root, epoch);
    this.applyStyles(prepared);
  }

  recordFailure(error: unknown): void {
    if (!isAppearanceFailure(error)) { throw error; }
    this.failure = error instanceof Error ? error.message : String(error);
    reportError(error);
  }

  async open(container: HTMLElement): Promise<void> {
    await this.closeSettings();
    const pageEpoch = this.pageEpoch;
    try { await this.reload(); }
    catch (error) { this.recordFailure(error); }
    if (pageEpoch !== this.pageEpoch || this.app.changingVault) { throw new AppearanceError("The Appearance settings page was closed while loading."); }
    container.replaceChildren(this.containerEl);
    await this.showSettings();
  }

  override async closeSettings(): Promise<void> { await super.closeSettings(); this.pageEpoch++; }

  override getControlValue(key: string): unknown {
    const options = appearanceOptions(this.document?.data ?? {});
    if (key === "theme" || key === "cssTheme") { return options[key]; }
    if (key.startsWith("snippet:")) { return options.enabledCssSnippets.includes(appearanceName(key.slice(8))); }
    throw new AppearanceError("This Appearance setting is not supported: " + key);
  }

  override async setControlValue(key: string, value: unknown): Promise<void> {
    await this.change(data => {
      if (key === "theme" || key === "cssTheme") { data[key] = value; }
      else if (key.startsWith("snippet:") && typeof value === "boolean") {
        const name = appearanceName(key.slice(8)), before = appearanceOptions(data).enabledCssSnippets;
        data.enabledCssSnippets = value ? [...new Set([...before, name])] : before.filter(item => item !== name);
      } else { throw new AppearanceError("This Appearance setting is not supported: " + key); }
    });
  }

  private assertOwner(root: string | null, epoch: number): void {
    if (!root || root !== this.app.vault.rootPath || epoch !== this.assetEpoch) { throw new AppearanceError("These appearance assets belong to an inactive vault."); }
  }

  private change(update: (data: Record<string, unknown>) => void): Promise<void> {
    const root = this.app.vault.rootPath, epoch = this.assetEpoch, pageEpoch = this.pageEpoch;
    const save = async (): Promise<void> => {
      this.assertOwner(root, epoch);
      const previous = this.document;
      if (!previous || previous.root !== root || pageEpoch !== this.pageEpoch || this.app.changingVault || !this.containerEl.isConnected) {
        throw new AppearanceError("These Appearance settings belong to an inactive page.");
      }
      const data = { ...previous.data };
      update(data);
      const options = appearanceOptions(data);
      const prepared = await this.prepareStyles(options, root, epoch);
      this.assertOwner(root, epoch);
      if (pageEpoch !== this.pageEpoch || this.app.changingVault || !this.containerEl.isConnected) { throw new AppearanceError("The Appearance settings page changed before saving."); }
      const saved = await this.app.configuration.write(previous, data);
      this.assertOwner(root, epoch);
      this.document = saved;
      this.mode = options.theme;
      this.applyStyles(prepared, false);
      this.failure = this.inventoryFailure;
      this.applyMode();
      this.refreshDomState();
    };
    return this.enqueue(save);
  }

  private enqueue(action: () => Promise<void>): Promise<void> {
    const operation = this.writes.then(action, action);
    this.writes = operation;
    return operation;
  }

  private async inventory(): Promise<{ themes: AppearanceAsset[]; snippets: AppearanceAsset[] }> {
    const list = async (path: string): Promise<{ files: string[]; folders: string[] }> => {
      const stat = await this.app.vault.adapter.stat(path);
      if (!stat) { return { files: [], folders: [] }; }
      if (stat.type !== "folder") { throw new AppearanceError("The appearance asset path is not a folder: " + path); }
      return this.app.vault.adapter.list(path);
    };
    const [themes, snippets] = await Promise.all([list(".obsidian/themes"), list(".obsidian/snippets")]);
    if (themes.folders.length + snippets.files.length > 256) { throw new AppearanceError("Appearance supports at most 256 installed themes and snippet files."); }
    const found = await Promise.all(themes.folders.filter(folder => !folder.slice(".obsidian/themes/".length).startsWith(".")).map(async folder => {
      const name = appearanceName(folder.slice(".obsidian/themes/".length)), path = appearanceCssPath(folder + "/theme.css");
      return (await this.app.vault.adapter.stat(path))?.type === "file" ? { name, path } : null;
    }));
    const result = {
      themes: found.filter((asset): asset is AppearanceAsset => asset !== null).sort((a, b) => a.name.localeCompare(b.name)),
      snippets: snippets.files.filter(path => /\.css$/i.test(path) && !path.slice(".obsidian/snippets/".length).startsWith(".")).map(path => ({ name: appearanceName(path.slice(".obsidian/snippets/".length, -4)), path: appearanceCssPath(path) })).sort((a, b) => a.name.localeCompare(b.name)),
    };
    if (new Set(result.snippets.map(asset => asset.name)).size !== result.snippets.length) { throw new AppearanceError("Multiple CSS snippets have the same saved name. Give them distinct names before loading."); }
    return result;
  }

  private async readInventory(root: string | null, epoch: number, pageEpoch?: number): Promise<void> {
    const assertOwner = (): void => {
      this.assertOwner(root, epoch);
      if (pageEpoch !== undefined && pageEpoch !== this.pageEpoch) { throw new AppearanceError("The Appearance settings page was closed while discovering CSS."); }
    };
    const assets = await this.inventory().catch((error: unknown) => {
      if (!isAppearanceFailure(error)) { throw error; }
      assertOwner();
      this.inventoryFailure = error instanceof Error ? error.message : String(error);
      throw error;
    });
    assertOwner();
    this.assets = assets;
    this.inventoryFailure = "";
  }

  private async prepareStyles(options: AppearanceOptions, root: string | null, epoch: number): Promise<HTMLStyleElement[]> {
    if (!root) { throw new AppearanceError("Open a vault before loading appearance styles."); }
    this.assertOwner(root, epoch);
    const paths = [
      ...(options.cssTheme ? [this.assets.themes.find(asset => asset.name === options.cssTheme)?.path ?? `.obsidian/themes/${options.cssTheme}/theme.css`] : []),
      ...options.enabledCssSnippets.map(name => this.assets.snippets.find(asset => asset.name === name)?.path ?? `.obsidian/snippets/${name}.css`),
    ];
    const prepared: HTMLStyleElement[] = [];
    let bytes = 0;
    for (const path of paths) {
      const stylesheet: AppearanceStylesheet = await requestJson<AppearanceStylesheet>("/api/appearance/css?" + new URLSearchParams({ root, path: appearanceCssPath(path) }));
      this.assertOwner(root, epoch);
      if (stylesheet.root !== root || stylesheet.path !== path || typeof stylesheet.content !== "string"
        || !Number.isSafeInteger(stylesheet.size) || stylesheet.size < 0 || stylesheet.size > APPEARANCE_CSS_BYTES
        || new TextEncoder().encode(stylesheet.content).length > stylesheet.size) { throw new AppearanceError("The host returned an invalid appearance stylesheet."); }
      validateAppearanceCss(stylesheet.content);
      bytes += stylesheet.size;
      if (bytes > 4 * 1024 * 1024) { throw new AppearanceError("The selected appearance styles exceed the 4 MiB total limit."); }
      const style = document.createElement("style");
      style.dataset.appearanceStyle = path;
      style.textContent = stylesheet.content;
      prepared.push(style);
    }
    return prepared;
  }

  private applyStyles(prepared: HTMLStyleElement[], notify = true): void {
    this.styles.forEach(style => style.remove());
    document.head.append(...prepared);
    this.styles = prepared;
    if (notify) { this.app.workspace.trigger("css-change"); }
  }

  private applyMode(): void {
    const dark = this.mode === "obsidian" || this.mode === "system" && this.system.matches;
    for (const element of [document.documentElement, document.body]) {
      element.classList.toggle("theme-dark", dark);
      element.classList.toggle("theme-light", !dark);
    }
    for (const leaf of this.app.workspace.getLeavesOfType("markdown")) {
      if (leaf.view instanceof MarkdownView) { leaf.view.editor.setDarkMode(dark); }
    }
    this.app.workspace.trigger("css-change");
  }

  private async reload(): Promise<void> {
    const root = this.app.vault.rootPath, epoch = this.assetEpoch, pageEpoch = this.pageEpoch;
    const configuration = await this.app.configuration.read("appearance");
    this.assertOwner(root, epoch);
    if (pageEpoch !== this.pageEpoch) { throw new AppearanceError("The Appearance settings page was closed while loading."); }
    this.document = configuration;
    const options = appearanceOptions(configuration.data);
    this.mode = options.theme;
    this.applyMode();
    try {
      await this.readInventory(root, epoch, pageEpoch);
      const prepared = await this.prepareStyles(options, root, epoch);
      this.assertOwner(root, epoch);
      if (pageEpoch !== this.pageEpoch) { throw new AppearanceError("The Appearance settings page was closed while loading CSS."); }
      this.applyStyles(prepared);
      this.failure = "";
    } catch (error) { this.recordFailure(error); }
  }

  override getSettingDefinitions(): SettingDefinitionItem[] {
    let options: AppearanceOptions | null = null;
    if (this.document) {
      try { options = appearanceOptions(this.document.data); }
      catch (error) { if (!(error instanceof AppearanceError)) { throw error; } this.failure = error.message; }
    }
    const refreshAction = (): Promise<void> => this.enqueue(async () => {
      try { await this.reload(); }
      catch (error) { this.recordFailure(error); }
      this.update();
    });
    const refresh: SettingDefinitionItem = {
      name: "Reload appearance and CSS files", desc: "Read external appearance.json changes and discover/reread local CSS without rewriting its bytes.", action: refreshAction,
    };
    const failure: SettingDefinitionItem = {
      name: "Appearance loading failed", desc: this.failure || "This vault's appearance preferences have not been read.", visible: () => Boolean(this.failure) || !this.document, render: setting => {
        setting.settingEl.dataset.appearanceFailure = "";
        setting.settingEl.setAttribute("role", "alert");
      },
    };
    if (!options) {
      return [failure, refresh, {
        name: "Reset supported appearance preferences", desc: "Explicitly restore dark mode, the default theme and no snippets. Unrelated keys and CSS files are retained; malformed JSON must be corrected on disk first.",
        disabled: !this.document, action: async () => {
          await this.change(data => { data.theme = "obsidian"; data.cssTheme = ""; data.enabledCssSnippets = []; });
          await refreshAction();
        },
      }];
    }
    const themeOptions = Object.fromEntries([["", "Default"], ...this.assets.themes.map(asset => [asset.name, asset.name])]);
    if (options.cssTheme && !Object.hasOwn(themeOptions, options.cssTheme)) { Object.defineProperty(themeOptions, options.cssTheme, { value: options.cssTheme + " (missing)", enumerable: true }); }
    const snippets = [...new Set([...this.assets.snippets.map(asset => asset.name), ...options.enabledCssSnippets])];
    return [
      { type: "group", heading: "Appearance", items: [
        { name: "Base color scheme", desc: "Use a dark or light interface, or follow the operating system. Existing note text, selection and undo are retained.", control: { type: "dropdown", key: "theme", options: { obsidian: "Dark", moonstone: "Light", system: "Adapt to system" } } },
        { name: "Installed theme", desc: "Loads .obsidian/themes/<name>/theme.css. Only self-contained CSS is supported; imports and URL/image resources refuse. Only enable CSS you trust: it can restyle the entire interface. Complete native theme/DOM compatibility is not supplied.", control: { type: "dropdown", key: "cssTheme", options: themeOptions } },
      ] },
      failure,
      { type: "group", heading: "CSS snippets", items: snippets.map(name => ({
        name, desc: this.assets.snippets.find(asset => asset.name === name)?.path ?? "Missing snippet; its saved name is retained.",
        control: { type: "toggle", key: "snippet:" + name },
      })), emptyState: "No top-level .css files were found in .obsidian/snippets. Add a trusted local file, then reload." },
      refresh,
      { name: "Disable custom styles", desc: "Return to the default theme and disable every snippet. CSS files and unrelated appearance preferences are retained.", action: async () => {
        await this.change(data => { data.cssTheme = ""; data.enabledCssSnippets = []; });
        this.update();
      } },
    ];
  }
}
