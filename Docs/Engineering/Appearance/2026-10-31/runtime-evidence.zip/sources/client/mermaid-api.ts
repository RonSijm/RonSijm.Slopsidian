export { default } from "mermaid";
