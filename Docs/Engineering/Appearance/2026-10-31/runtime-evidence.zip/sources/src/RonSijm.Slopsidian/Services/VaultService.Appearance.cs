using System.Security.Cryptography;
using System.Text;

namespace RonSijm.Slopsidian.Services;

public sealed partial class VaultService
{
    public async Task<AppearanceStylesheet> ReadAppearanceCssAsync(string expectedRoot, string path, CancellationToken cancellationToken = default)
    {
        var parts = path.Split('/');
        if (!(parts.Length == 4 && parts[0] == ".obsidian" && parts[1] == "themes" && parts[3] == "theme.css"
            || parts.Length == 3 && parts[0] == ".obsidian" && parts[1] == "snippets" && parts[2].EndsWith(".css", StringComparison.OrdinalIgnoreCase)))
        {
            throw new VaultException("Only installed theme.css and top-level CSS snippet files can be loaded.");
        }

        var name = parts.Length == 4 ? parts[2] : parts[2][..^4];
        if (name.Length > 200 || InvalidPathSegment(name))
        {
            throw new VaultException("Use a theme or snippet name without hidden, reserved, traversal or invalid path characters.");
        }

        await gate.WaitAsync(cancellationToken);
        try
        {
            RequireFileOperationRoot(expectedRoot);
            var fullPath = Resolve(path, allowHidden: true);
            if (!File.Exists(fullPath))
            {
                throw new VaultException("This appearance stylesheet is missing: " + path, StatusCodes.Status404NotFound);
            }

            await using var stream = new FileStream(fullPath, FileMode.Open, FileAccess.Read, FileShare.Read, 8192, FileOptions.Asynchronous);
            if (stream.Length > 1024 * 1024)
            {
                throw new VaultException("Each appearance stylesheet must be at most 1 MiB.", StatusCodes.Status413PayloadTooLarge);
            }

            var bytes = new byte[checked((int)stream.Length)];
            await stream.ReadExactlyAsync(bytes, cancellationToken);
            string content;
            try
            {
                content = new UTF8Encoding(false, true).GetString(bytes);
            }
            catch (DecoderFallbackException)
            {
                throw new VaultException("Appearance CSS must be valid UTF-8 text.", StatusCodes.Status415UnsupportedMediaType);
            }

            return new AppearanceStylesheet(RequireRoot(), path, content, Convert.ToHexStringLower(SHA256.HashData(bytes)), bytes.Length);
        }
        finally
        {
            gate.Release();
        }
    }
}
