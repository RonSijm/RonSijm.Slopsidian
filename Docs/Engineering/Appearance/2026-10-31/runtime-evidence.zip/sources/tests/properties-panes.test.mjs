import assert from "node:assert/strict";
import { before, after, test } from "node:test";
import { build } from "esbuild";
import { mkdir, mkdtemp, rm } from "node:fs/promises";
import { join, relative } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { frontmatterPropertyPosition } from "../client/markdown.ts";

const root = fileURLToPath(new URL("../", import.meta.url));
let directory, propertiesPaneState, sortedProperties, MetadataTypeManager;
before(async () => {
  await mkdir(join(root, ".runtime"), { recursive: true }); directory = await mkdtemp(join(root, ".runtime", "properties-pane-tests-"));
  const outfile = join(directory, "properties.mjs");
  await build({ stdin: { contents: 'export * from "./client/properties-pane-model"; export { MetadataTypeManager } from "./client/property-types";', resolveDir: root }, outfile, bundle: true, packages: "external", platform: "node", format: "esm", logLevel: "silent" });
  ({ propertiesPaneState, sortedProperties, MetadataTypeManager } = await import(pathToFileURL(outfile).href));
});
after(async () => {
  if (directory) { assert.match(relative(root, directory).replaceAll("\\", "/"), /^\.runtime\/properties-pane-tests-[^/]+$/); await rm(directory, { recursive: true }); }
});

test("Properties imports retain independent filters, targets and catalog folds with legacy file pinning", () => {
  const input = { file: "Notes/Source.md", query: "<literal>", sort: "frequency", expandedProperties: ["Title", "TITLE"], opaque: { keep: true } }, before = structuredClone(input);
  const first = propertiesPaneState(input), second = propertiesPaneState(input);
  assert.equal(first.followActiveFile, false); assert.deepEqual(first.expandedProperties, ["title"]);
  first.file = "Other.md"; first.expandedProperties.push("other");
  assert.deepEqual(second.expandedProperties, ["title"]); assert.equal(second.file, input.file); assert.deepEqual(input, before);
  assert.equal(propertiesPaneState({}).followActiveFile, true);
  assert.equal(propertiesPaneState({ file: input.file, followActiveFile: true }).followActiveFile, true);
});
test("malformed Properties state refuses rather than coercing paths, filters, sorts or folds", () => {
  for (const state of [
    { query: null }, { query: "x".repeat(1025) }, { sort: "__proto__" }, { sort: null }, { followActiveFile: null }, { followActiveFile: 0 },
    { expandedProperties: null }, { expandedProperties: [""] }, { expandedProperties: Array(1025).fill("a") },
    ...["/note.md", "../note.md", ".obsidian/app.json", "a//b.md", "a\\b.md", "a\u0000b.md", ""].map(file => ({ file })),
  ]) { assert.throws(() => propertiesPaneState(state)); }
});
test("Properties filtering and four sorts preserve source entries and deterministic frequency ties", () => {
  const entries = [{ name: "Beta", occurrences: 2 }, { name: "alpha", occurrences: 3 }, { name: "gamma", occurrences: 2 }], before = structuredClone(entries);
  const names = (sort, query = "") => sortedProperties(entries, query, sort).map(entry => entry.name);
  assert.deepEqual(names("name"), ["alpha", "Beta", "gamma"]);
  assert.deepEqual(names("nameReverse"), ["gamma", "Beta", "alpha"]);
  assert.deepEqual(names("frequency"), ["alpha", "Beta", "gamma"]);
  assert.deepEqual(names("frequencyReverse"), ["Beta", "gamma", "alpha"]);
  assert.deepEqual(names("name", "ALP"), ["alpha"]); assert.deepEqual(entries, before);
});
test("property catalog occurrences count notes once even with case-distinct YAML keys", () => {
  const app = { vault: { rootPath: "fixture" }, metadataCache: { on() {}, getDocuments: () => [
    { document: { file: { extension: "md" } }, cache: { frontmatter: { Label: "one", label: "two", title: "First" } } },
    { document: { file: { extension: "md" } }, cache: { frontmatter: { LABEL: 3 } } },
  ] } };
  const manager = new MetadataTypeManager(app);
  manager.accept({ root: "fixture", id: "types", version: null, data: {} });
  assert.deepEqual(manager.getPropertyInfo("label"), { name: "Label", widget: "unknown", occurrences: 2 });
  assert.equal(manager.getPropertyInfo("title").occurrences, 1);
});
test("catalog navigation selects actual top-level YAML key ranges including quoted CRLF keys", () => {
  const text = '\ufeff---\r\n# Keep comment\r\n"project: label": Alpha\r\nnested: {title: keep}\r\n---\r\n# Body\r\n';
  const location = frontmatterPropertyPosition(text, "project: label");
  assert.equal(text.slice(location.start.offset, location.end.offset), '"project: label"');
  assert.equal(location.start.line, 2);
  assert.equal(frontmatterPropertyPosition(text, "title"), null);
  assert.equal(frontmatterPropertyPosition("---\nbroken: [\n---\n", "broken"), null);
});
