import assert from "node:assert/strict";
import { after, before, test } from "node:test";
import { build } from "esbuild";
import { mkdir, mkdtemp, rm } from "node:fs/promises";
import { join, relative } from "node:path";
import { pathToFileURL } from "node:url";
import { root } from "./host.mjs";

let directory, appearanceOptions, appearanceCssPath, validateAppearanceCss;
before(async () => {
  await mkdir(join(root, ".runtime"), { recursive: true });
  directory = await mkdtemp(join(root, ".runtime", "appearance-tests-"));
  const outfile = join(directory, "appearance.mjs");
  await build({ entryPoints: [join(root, "client", "appearance-model.ts")], outfile, bundle: true, platform: "node", format: "esm", logLevel: "silent" });
  ({ appearanceOptions, appearanceCssPath, validateAppearanceCss } = await import(pathToFileURL(outfile).href));
});
after(async () => {
  if (directory) {
    assert.match(relative(root, directory).replaceAll("\\", "/"), /^\.runtime\/appearance-tests-[^/]+$/);
    await rm(directory, { recursive: true });
  }
});

test("appearance reads native-shaped modes and literal installed names without mutating unknown preferences", () => {
  const data = { theme: "system", cssTheme: "Theme café", enabledCssSnippets: ["One", "Two", "One"], future: { keep: true } };
  const original = structuredClone(data);
  assert.deepEqual(appearanceOptions(data), { theme: "system", cssTheme: "Theme café", enabledCssSnippets: ["One", "Two"] });
  assert.deepEqual(data, original);
  assert.deepEqual(appearanceOptions({}), { theme: "obsidian", cssTheme: "", enabledCssSnippets: [] });
  for (const invalid of [
    { theme: null }, { theme: "dark" }, { cssTheme: null }, { cssTheme: "../foreign" },
    { enabledCssSnippets: null }, { enabledCssSnippets: ["Valid", "CON"] },
    { enabledCssSnippets: ["Valid", ".hidden"] }, { enabledCssSnippets: Array(129).fill("Repeated") },
  ]) { const before = structuredClone(invalid); assert.throws(() => appearanceOptions(invalid)); assert.deepEqual(invalid, before); }
});

test("appearance paths allow only real top-level snippets and installed theme CSS with safe literal names", () => {
  for (const path of [".obsidian/themes/Theme café/theme.css", ".obsidian/snippets/Notes layout.css", ".obsidian/snippets/Upper.CSS"]) {
    assert.equal(appearanceCssPath(path), path);
  }
  for (const path of [
    "Notes.css", ".obsidian/app.json", ".obsidian/plugins/demo/styles.css",
    ".obsidian/snippets/nested/Hidden.css", ".obsidian/themes/../theme.css",
    ".obsidian/themes/.hidden/theme.css", ".obsidian/snippets/CON.css",
    ".obsidian/snippets/Trailing .css", ".obsidian/snippets/a\\b.css", ".OBSIDIAN/snippets/Foreign.css",
  ]) { assert.throws(() => appearanceCssPath(path), path); }
});

test("self-contained CSS permits literal content/comments but refuses escaped imports and resource-loading functions", () => {
  assert.doesNotThrow(() => validateAppearanceCss('\ufeff/* @import url("never fetched") */\r\nbody { --text-normal: #252525; } .note::after { content: "url(only literal text)"; }\r\n'));
  for (const css of [
    '@import "remote.css";', '@\\69mport "remote.css";', '@\\000069 mport url("remote.css");',
    'body { background: URL("https://example.invalid/"); }',
    'body { background: u\\72l("https://example.invalid/"); }',
    'body { background: image-set("https://example.invalid/image" 1x); }',
    'body { background: -webkit-image-set("https://example.invalid/image" 1x); }',
    'body { background: image("https://example.invalid/image"); }',
    '@font-face { src: src("https://example.invalid/font"); }',
    'body { background: url("data:image/png;base64,AAAA"); }',
  ]) { assert.throws(() => validateAppearanceCss(css), /self-contained/, css); }
});

test("invalid and oversized CSS refuses before insertion, including byte-sized Unicode and incomplete lexical input", () => {
  for (const css of ['body { content: "unterminated; }', 'body { content: "bad\n; background:url(https://example.invalid/); } "', "/* no end", "body { color: \\",
    "body { color: u\\\nrl(https://example.invalid/); }",
    "body { color: \0; }", "/*" + "é".repeat(524288) + "*/"]) {
    assert.throws(() => validateAppearanceCss(css));
  }
  assert.doesNotThrow(() => validateAppearanceCss('body { --label: "escaped \\" quote"; color: red; }'));
  assert.doesNotThrow(() => validateAppearanceCss('body { --label: "escaped\\\r\n continuation"; color: red; }'));
});
